rm(list=ls())
library('rstan')
library('Rcpp')

# set up parameter values:
N       <- 500 # no. of cases/controls.

seed_start <- 20150923
set.seed(seed_start)

p <- 1
X0 <- matrix(runif(N*p,0,1),nrow=N,ncol=p)
X  <- apply(X0,2,scale)

f1 <- function(x) {sin(8*pi*(x-0.5)/7)}
f2 <- function(x) {-0.5*sin(2*pi*x)/(pi*x)}
f3 <- function(x) {-0.5*sin(8*pi*(x-0.5)/7)}
f4 <- function(x) {0}
f5 <- function(x) {4*(exp(3*x)/(1+exp(3*x))-0.5)}
f6 <- function(x) {0}
f  <- f1
x  <- sort(X[,1])
mu <- f(x)

sigma <- 1
y  <- mu + rnorm(N,0,sigma)

plot(x,y)
points(x,mu,col="blue",lwd=2)

# include stratification information in file name:
dated_strat_name    <- file.path(paste0("Stan"))
# create folder
dir.create(dated_strat_name)
fullname <- dated_strat_name

# for finer scenarios, e.g., different types of analysis applicable to the
# same data set. Here we just perform one analysis:
result_folder <- fullname
dir.create(result_folder)

# prepare data:
M <- y
C0 <- 10
C  <- C0

myknots2 <- quantile(x,seq(0,1,length = (C0 - 2))[-c(1,(C0 - 2))])
ZB       <- matrix(splines::bs(x,knots= myknots2,intercept=TRUE),nrow=N)

setwd("/Users/zhenkewu/Dropbox/ZW/professional/teaching/graphical\ models/notes/lecture14/code/Stan")

fit <- stan('model.stan',
            data=c("M","C","ZB","N"),
            iter=10000,warmup=5000,thin=5, chains=1)
print(fit)

res <- extract(fit,permuted=TRUE)

res_mu <- res$mu

png(file.path(result_folder,"estimated_mean_curve.png"),
    width=10,height=8,units = "in",res=72)
par(mar=c(5,5,3,3))
matplot(x,t(res_mu),type="l",col=2,main=paste0("Mean curve"),
        xlab="x",ylab="y",
        ylim=c(-6,4))

points(x,y)
points(x,mu,col="black",lty=1,lwd=4,type="l")

#par(mar=c(4,5,0,3))
beta_postmean <- colMeans(res$beta)
ZB_new <- sweep(ZB,MARGIN = 2,STATS = beta_postmean,"/")
#matplot(x,ZB_new,type="l",lwd=2,ylim=c(-2,2),xlab="x",ylab="")
matplot(x,ZB_new-5,type="l",lwd=2,add=TRUE)
abline(h=-4)
dev.off()


# to explore the posterior:
library(shinystan)
my_sso <- launch_shinystan(fit)
